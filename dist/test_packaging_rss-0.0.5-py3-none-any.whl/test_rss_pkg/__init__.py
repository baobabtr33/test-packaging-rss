name = "test-packaging-rss"
print("test rss pkg loaded")

