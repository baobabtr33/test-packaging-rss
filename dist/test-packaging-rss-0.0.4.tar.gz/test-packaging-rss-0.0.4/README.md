# test-packaging-rss

패키징 Test  

Test Pypi Link:  
https://test.pypi.org/project/test-packaging-rss/  
  
  
## Installation
<pre>
<code>
  $ python - m pip install -i https://test.pypi.org/simple/ test-packaging-rss
  $ python - m pip install feedparser
</code>
</pre>
  
  
